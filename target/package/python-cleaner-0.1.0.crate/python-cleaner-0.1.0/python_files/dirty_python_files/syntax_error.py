def calculate_total(a, b):
    	result = a + b\
	return result

def greet(name):
	message = "Hello, " + name\
	print(message)

print(calculate_total(3, 5))
greet("Alice")
