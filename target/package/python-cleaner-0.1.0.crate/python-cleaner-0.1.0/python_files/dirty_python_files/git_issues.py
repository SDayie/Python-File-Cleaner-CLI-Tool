def greet(name):    
    print("Hello", name)    


    
    print("Welcome!")    


