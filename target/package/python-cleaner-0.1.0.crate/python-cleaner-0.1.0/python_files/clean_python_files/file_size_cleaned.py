def say_hi():

    print("Hi")

    print("How are you?")
