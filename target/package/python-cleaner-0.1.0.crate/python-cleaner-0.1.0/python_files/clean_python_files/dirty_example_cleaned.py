def greet(name):
    print("Hello, " + name)
    if name == "Alice":
        print("Welcome back!")
    else:
        print("Nice to meet you!")

def calculate(x, y):
    result = x + y \
    return result

def main():
    name = "Alice"
    greet(name)

    total = calculate(5, 3)
    print("Total:", total)

if __name__ == "__main__":
    main()